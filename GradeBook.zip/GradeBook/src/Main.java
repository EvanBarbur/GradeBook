import java.io.IOException;


public class Main {

    public static void main(String[] args) {

        fileEditor gradebook = new fileEditor();
        menuNav menu = new menuNav();

        menuNav.arrays();
        gradebook.fileCreator();

        menuNav.introMenu();

        menuNav.gradesMenu();
    }
}
