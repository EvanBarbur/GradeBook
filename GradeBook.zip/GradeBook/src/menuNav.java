import java.util.InputMismatchException;
import java.util.Scanner;

public class menuNav {

    // Arrays in main scope
    private static final String[] CLASSES = {"Biology", "Calculus", "Physics", "Programming", "Government", "Humanities", "English"};
    private static final String[] TYPES = {"Quizzes", "Exams", "Homework", "Projects"};
    private static final String[][] grade_book = new String[CLASSES.length + 1][TYPES.length + 3];

    public static void arrays() {

        // Expand on 2D array and formats
        grade_book[0][5] = ("FINAL");
        grade_book[0][6] = ("LETTER");

        for (int i = 1; i < 8; i++) {
            grade_book[i][0] = CLASSES[i - 1];
        }
        for (int j = 1; j < 5; j++) {
            grade_book[0][j] = TYPES[j - 1];
        }
    }


    public static void introMenu() {

        // user inputs name
        Scanner scan = new Scanner(System.in);
        System.out.println("Please enter in your name.");
        String studentName = scan.nextLine();

        grade_book[0][0] = studentName;

        // System says hello and prints main menu
        System.out.println();
        System.out.println("Hello " + studentName + ".");
    }

    public static void gradesMenu() {

        // program end check
        boolean check = false;
        while (!check) {

        // System prints out grades menu
        System.out.println();
        System.out.println("Would you like to enter in new grades, review old grades, or exit the program? (1, 2, 3)");
        System.out.println("1. Enter New grades");
        System.out.println("2. Review Old Grades");
        System.out.println("3. Exit Program");

        // User inputs grades menu option
        Scanner scan3 = new Scanner(System.in);
        int option2 = scan3.nextInt();

        // Proper input check
        if (option2 == 1) {
            classMenu();
        } else if (option2 == 2) {
            fileEditor gradebook = new fileEditor();
            gradebook.fileReader();
        } else if (option2 == 3) {
            check = true;
        } else {
            System.out.println("Please select an option. (1, 2, 3)");
        }
        }
    }

    public static void classMenu() {

        // Done entering grades check
        boolean done = false;
        while (!done) {

            // System asks which class and prints options
            System.out.println("Which class would you like to enter grades for?");
            for (String classes : CLASSES) {
                System.out.println(classes);
            }

            // User inputs class option
            Scanner scan4 = new Scanner(System.in);
            String classType = scan4.nextLine().toLowerCase();

            // Class found check
            boolean classFound = false;

            for (String item : CLASSES) {
                if (classType.equals(item.toLowerCase())) {

                    // class found
                    classFound = true;
                    enterMenu(classType);
                    System.out.println("Are you done entering grades?");
                    Scanner scan5 = new Scanner(System.in);
                    String doneCheck = scan5.nextLine().toLowerCase();
                    if (doneCheck.equals("yes") || doneCheck.equals("y")) {
                        done = true;
                    }
                }

            }
            if (!classFound) {
                System.out.println("The class " + classType + " was not found");
            }
        }
        grades.calcGrade(grade_book);
    }

    public static void enterMenu(String classType) {

        // Gets grade input
        for (int i=0; i < TYPES.length; i++) {

            Scanner points = new Scanner(System.in);

            boolean intCheck = false;
            while (!intCheck) {

                try {
                    System.out.println();
                    System.out.println("Please enter in your total points in " + TYPES[i]);

                    int grade = points.nextInt();
                    points.nextLine();

                    // end while loop of input is Integer
                    intCheck = true;
                    int index = 0;

                    for (int j=0; j < CLASSES.length; j++) {
                        if (classType.equals(CLASSES[j].toLowerCase())) {
                            index = j;
                        }
                    }

                    grade_book[index+1][i+1] = Integer.toString(grade);

                    // verify
                    System.out.println();
                    System.out.println("The " + TYPES[i] + " points of " + grade + " has been entered in for the " + classType + " class.");

                    // Catches error if input is not an integer
                } catch (InputMismatchException ime) {
                    System.out.println();
                    System.out.println("Invalid Entry, Please enter in a number.");
                    points.nextLine();
                }
            }
        }
    }
}