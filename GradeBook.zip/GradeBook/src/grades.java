public class grades {
    public static void calcGrade(String[][] grade_book) {

        int quizPercent;
        int examPercent;
        int hwPercent;
        int projPercent;


        int examGrade = 0;
        int quizGrade = 0;
        int hwGrade = 0;
        int projGrade = 0;
        int finalGrade;

        int MAX_POINTS = 700;
        int QUIZ_POINTS = 225;
        int EXAM_POINTS = 100;
        int HW_POINTS = 250;
        int PROJ_POINTS = 125;
        double QUIZ_WEIGHT = 0.2;
        double EXAM_WEIGHT = 0.3;
        double HW_WEIGHT = 0.25;
        double PROJ_WEIGHT = 0.25;

        int[][] intGrade = new int[7][4];

        for (int i = 1; i < 8; i++) {
            for (int j = 1; j < 5; j++) {
                if (grade_book[i][j] != null) {
                    intGrade[i - 1][j - 1] = Integer.parseInt(grade_book[i][j]);
                    switch (j) {
                        case 1:
                            quizPercent = (int) Math.round((double) intGrade[i - 1][j - 1] / QUIZ_POINTS * 100);
                            quizGrade = (int) Math.round(quizPercent * QUIZ_WEIGHT);
                            grade_book[i][j] = Integer.toString(quizPercent);
                            break;
                        case 2:
                            examPercent = (int) Math.round((double) intGrade[i - 1][j - 1] / EXAM_POINTS * 100);
                            examGrade = (int) Math.round(examPercent * EXAM_WEIGHT);
                            grade_book[i][j] = Integer.toString(examPercent);
                            break;
                        case 3:
                            hwPercent = (int) Math.round((double) intGrade[i - 1][j - 1] / HW_POINTS * 100);
                            hwGrade = (int) Math.round(hwPercent * HW_WEIGHT);
                            grade_book[i][j] = Integer.toString(hwPercent);
                            break;
                        case 4:
                            projPercent = (int) Math.round((double) intGrade[i - 1][j - 1] / PROJ_POINTS * 100);
                            projGrade = (int) Math.round(projPercent * PROJ_WEIGHT);
                            grade_book[i][j] = Integer.toString(projPercent);
                            break;
                    }

                    finalGrade = (int) (quizGrade + examGrade + hwGrade + projGrade);
                    if (finalGrade == 0) {
                        grade_book[i][5] = ("N/A");
                        grade_book[i][6] = ("N/A");
                    } else if (finalGrade >= 90) {
                        grade_book[i][6] = ("A - Congrats!");
                    } else if (finalGrade >= 80) {
                        grade_book[i][6] = ("B");
                    } else if (finalGrade >= 70) {
                        grade_book[i][6] = ("C");
                    } else if (finalGrade >= 60) {
                        grade_book[i][6] = ("D");
                    } else {
                        grade_book[i][6] = ("F");
                    }
                    grade_book[i][5] = Integer.toString(finalGrade);
                }
            }

        }

        fileEditor gradebook = new fileEditor();
        gradebook.fileWriter(grade_book);
    }
}





